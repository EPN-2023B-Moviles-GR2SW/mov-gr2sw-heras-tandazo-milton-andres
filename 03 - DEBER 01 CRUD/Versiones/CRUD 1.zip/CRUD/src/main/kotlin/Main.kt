import vista.MenuPrincipalVista

fun main(args: Array<String>){
    MenuPrincipalVista()
}