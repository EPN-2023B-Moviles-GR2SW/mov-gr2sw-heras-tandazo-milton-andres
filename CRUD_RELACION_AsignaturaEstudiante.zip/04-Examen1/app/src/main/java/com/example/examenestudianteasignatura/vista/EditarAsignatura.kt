package com.example.examenestudianteasignatura.vista

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.annotation.RequiresApi
import com.example.examenestudianteasignatura.R
import com.example.examenestudianteasignatura.controlador.BaseDatosMemoria
import com.example.examenestudianteasignatura.modelo.Asignatura

class EditarAsignatura : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_asignatura)

        val codigo = findViewById<EditText>(R.id.inputEditarCodigo)
        val nombre = findViewById<EditText>(R.id.inputEditarNombreAsignatura)
        val horario = findViewById<EditText>(R.id.inputEditarHorario)
        val creditos = findViewById<EditText>(R.id.inputEditarCreditos)
        val profesor = findViewById<EditText>(R.id.inputEditarProfesorACargo)

        nombre.setText(BaseDatosMemoria.asignaturaSeleccionada.nombre)
        codigo.setText(BaseDatosMemoria.asignaturaSeleccionada.codigo)
        horario.setText(BaseDatosMemoria.asignaturaSeleccionada.horario)
        creditos.setText(BaseDatosMemoria.asignaturaSeleccionada.creditos.toString())
        profesor.setText(BaseDatosMemoria.asignaturaSeleccionada.profesor)

        val btnEditarMateria = findViewById<Button>(R.id.btnEditarAsignatura)
        btnEditarMateria.setOnClickListener{
            editarMateria()
            irActividad(ListaAsignaturasa::class.java)
        }

        val btnCancelar = findViewById<Button>(R.id.btnCancelarEditarAsignatura)
        btnCancelar.setOnClickListener{
            irActividad(ListaAsignaturasa::class.java)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun editarMateria(){
        val codigo = findViewById<EditText>(R.id.inputEditarCodigo)
        val nombre = findViewById<EditText>(R.id.inputEditarNombreAsignatura)
        val horario = findViewById<EditText>(R.id.inputEditarHorario)
        val creditos = findViewById<EditText>(R.id.inputEditarCreditos)
        val profesorACargo = findViewById<EditText>(R.id.inputEditarProfesorACargo)

        val materiaEditada = Asignatura(
            nombre.text.toString(),
            codigo.text.toString(),
            horario.text.toString(),
            creditos.text.toString().toDouble(),
            profesorACargo.text.toString()
        )
        BaseDatosMemoria.estudianteSelecciondo.asignaturas.forEachIndexed { index, materia ->
            if (materia.codigo === BaseDatosMemoria.asignaturaSeleccionada.codigo) {
                BaseDatosMemoria.estudianteSelecciondo.asignaturas[index] = materiaEditada
            }
        }
    }

    fun irActividad (
        clase: Class <*>
    ) {
        val intent = Intent(this, clase)
        startActivity(intent)
    }
}