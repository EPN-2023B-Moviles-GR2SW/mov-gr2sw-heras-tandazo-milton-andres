package com.example.examenestudianteasignatura.vista

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.annotation.RequiresApi
import com.example.examenestudianteasignatura.MainActivity
import com.example.examenestudianteasignatura.R
import com.example.examenestudianteasignatura.controlador.BaseDatosMemoria
import com.example.examenestudianteasignatura.modelo.Estudiante
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class EditarEstudiante : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_estudiante)

        val nombre = findViewById<EditText>(R.id.inputEditarNombre)
        val cedula = findViewById<EditText>(R.id.inputEditarCedula)
        val edad = findViewById<EditText>(R.id.inputEditarEdad)
        val estado = findViewById<EditText>(R.id.inputEditarEstado)
        val fechaInscripcion = findViewById<EditText>(R.id.inputEditarFechaInscripcion)

        cedula.setText(BaseDatosMemoria.estudianteSelecciondo.cedula)
        nombre.setText(BaseDatosMemoria.estudianteSelecciondo.nombre)
        edad.setText(BaseDatosMemoria.estudianteSelecciondo.edad.toString())
        estado.setText(BaseDatosMemoria.estudianteSelecciondo.activo.toString())
        fechaInscripcion.setText(BaseDatosMemoria.estudianteSelecciondo.fechaInscripcion.toString())

        val btnEditarProfesor = findViewById<Button>(R.id.btnEditarEstudiante)
        btnEditarProfesor.setOnClickListener{
            editarProfesor()
            irActividad(MainActivity::class.java)
        }

        val btnCancelar = findViewById<Button>(R.id.btnCancelarEditarEstudiante)
        btnCancelar.setOnClickListener{
            irActividad(MainActivity::class.java)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun editarProfesor(){
        val nombre = findViewById<EditText>(R.id.inputEditarNombre)
        val cedula = findViewById<EditText>(R.id.inputEditarCedula)
        val edad = findViewById<EditText>(R.id.inputEditarEdad)
        val estado = findViewById<EditText>(R.id.inputEditarEstado)
        val estadoBoolean: Boolean = estado.text.toString().uppercase().equals("TRUE")
        val fechaInscripcion = findViewById<EditText>(R.id.inputEditarFechaInscripcion)
        try {
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            val fechaInscripcion = LocalDate.parse(fechaInscripcion.text.toString(), formatter)

            val estudianteEditado = Estudiante(
                cedula.text.toString(),
                nombre.text.toString(),
                edad.text.toString().toInt(),
                fechaInscripcion,
                estadoBoolean,
                BaseDatosMemoria.estudianteSelecciondo.asignaturas
            )
            BaseDatosMemoria.arregloEstudiantes.forEachIndexed{ index, estudiante ->
                if(estudiante.cedula === BaseDatosMemoria.estudianteSelecciondo.cedula ){
                    BaseDatosMemoria.arregloEstudiantes[index] = estudianteEditado
                }
            }

        } catch (e: DateTimeParseException) {
            // Podría incluir Snackbar en caso de error
        }


    }

    fun irActividad (
        clase: Class <*>
    ) {
        val intent = Intent(this, clase)
        startActivity(intent)
    }
}