package com.example.examenestudianteasignatura.vista

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.annotation.RequiresApi
import com.example.examenestudianteasignatura.R
import com.example.examenestudianteasignatura.controlador.BaseDatosMemoria
import com.example.examenestudianteasignatura.modelo.Asignatura

class CrearAsignatura : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_asignatura)
        val btnCrearNuevaAsignatura = findViewById<Button>(R.id.btnCrearNuevaAsignatura)
        btnCrearNuevaAsignatura.setOnClickListener{
            crarNuevaAsignatura()
            irActividad(ListaAsignaturasa::class.java)
        }

        val btnCancelar = findViewById<Button>(R.id.btnCancelarCrearAsignatura)
        btnCancelar.setOnClickListener{
            irActividad(ListaAsignaturasa::class.java)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun crarNuevaAsignatura(){
        val codigo = findViewById<EditText>(R.id.inputCodigo)
        val nombre = findViewById<EditText>(R.id.inputNombreAsignatura)
        val horas = findViewById<EditText>(R.id.inputHorario)
        val creditos = findViewById<EditText>(R.id.inputCreditos)
        val profesorACargo = findViewById<EditText>(R.id.inputProfesorACargo)

        val nuevaMateria = Asignatura(codigo.text.toString(),nombre.text.toString(), horas.text.toString(), creditos.text.toString().toDouble(), profesorACargo.text.toString())
        BaseDatosMemoria.estudianteSelecciondo.asignaturas.add(nuevaMateria)
    }

    fun irActividad (
        clase: Class <*>
    ) {
        val intent = Intent(this, clase)
        startActivity(intent)
    }
}