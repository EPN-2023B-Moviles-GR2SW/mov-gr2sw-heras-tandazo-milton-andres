package com.example.examenestudianteasignatura.vista

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.annotation.RequiresApi
import com.example.examenestudianteasignatura.MainActivity
import com.example.examenestudianteasignatura.R
import com.example.examenestudianteasignatura.controlador.BaseDatosMemoria
import com.example.examenestudianteasignatura.modelo.Estudiante
import com.google.android.material.snackbar.Snackbar
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class CrearEstudiante : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_estudiante)

        val btnCrearNuevoProsefor = findViewById<Button>(R.id.btnCrearNuevoEstudiante)
        btnCrearNuevoProsefor.setOnClickListener{
            crarNuevoEstudiante()
            irActividad(MainActivity::class.java)
        }

        val btnCancelar = findViewById<Button>(R.id.btnCancelarCrearEstudiante)
        btnCancelar.setOnClickListener{
            irActividad(MainActivity::class.java)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun crarNuevoEstudiante(){
        val nombre = findViewById<EditText>(R.id.inputNombre)
        val cedula = findViewById<EditText>(R.id.inputCedula)
        val edad = findViewById<EditText>(R.id.inputEdad)
        val fechaInscripcion = findViewById<EditText>(R.id.inputFechaInscripcion)
        val estado = findViewById<EditText>(R.id.inputEstado)
        val estadoBoolean: Boolean = estado.text.toString().uppercase().equals("VERDADERO")

        try {
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            val fechaInscripcion = LocalDate.parse(fechaInscripcion.text.toString(), formatter)

            val nuevoEstudiante = Estudiante(
                cedula.text.toString(),
                nombre.text.toString(),
                edad.text.toString().toInt(),
                fechaInscripcion,
                estadoBoolean
            )

            BaseDatosMemoria.arregloEstudiantes.add(nuevoEstudiante)

        } catch (e: DateTimeParseException) {
            Snackbar.make(findViewById(android.R.id.content), "Error al crear el estudiante: formato de fecha incorrecto", Snackbar.LENGTH_LONG).show()
        } catch (e: Exception) {
            // Manejo de otros tipos de excepciones si es necesario
            Snackbar.make(findViewById(android.R.id.content), "Error al crear el estudiante: ${e.message}", Snackbar.LENGTH_LONG).show()
        }
    }

    fun irActividad (
        clase: Class <*>
    ) {
        val intent = Intent(this, clase)
        startActivity(intent)
    }
}