package com.example.a04_deber03_tiktok

data class Friend (val user:String,
                   val estado: String,
                   val mensaje: String,
                   val photo:String)