package com.example.a04_deber03_tiktok

class FriendProvider {
    companion object{
        val friendList = listOf<Friend>(
            Friend(
                "Robert",
                "Online",
                "Vas a ir donde Juan?",
                "https://img.freepik.com/foto-gratis/chico-guapo-seguro-posando-contra-pared-blanca_176420-32936.jpg"
            ),
            Friend(
                "Beto",
                "Online",
                "Holaaa",
                "https://img.freepik.com/foto-gratis/hombre-moreno-positiva-brazos-cruzados_1187-5797.jpg"
            ),
            Friend(
                "Josh",
                "Offline",
                "Ya estoy en la clase",
                "https://concepto.de/wp-content/uploads/2018/08/persona-e1533759204552.jpg"
            ),
            Friend(
                "Amber",
                "Offline",
                "Lo que te decia ese día",
                "https://img.freepik.com/foto-gratis/retrato-hermoso-mujer-joven-posicion-pared-gris_231208-10760.jpg"
            ),
            Friend(
                "Justin",
                "Online",
                "Hakari goodddd",
                "https://cdn0.psicologia-online.com/es/posts/2/4/2/que_piensa_una_persona_cuando_dejas_de_buscarla_5242_600.jpg"
            ),
            Friend(
                "Fausto",
                "Online",
                "Que se mojo??????",
                "https://st3.depositphotos.com/3776273/31936/i/450/depositphotos_319362956-stock-photo-man-pointing-showing-copy-space.jpg"
            ),
            Friend(
                "Santiago",
                "Online",
                "Que se mojo????",
                "https://media.istockphoto.com/id/1301401050/es/foto/feliz-hombre-positivo-con-barba-gui%C3%B1ando-un-ojo-mirando-a-la-c%C3%A1mara-con-sonrisa-juguetona.jpg?s=612x612&w=0&k=20&c=jvGtstvxzvuWgUaJ7j3Fjjq1EoBBn4OXJcYWvhGiYQA="
            ),
            Friend(
                "Joan",
                "Online",
                "Lo que te decia ese día",
                "https://media.istockphoto.com/id/1080820554/es/foto/mi-confianza-es-natural.jpg?s=612x612&w=0&k=20&c=rgXTrqlGlbh0m7Iq8ij5EPJBcgZepjidndcIHmI03Sk="
            )

        )

    }
}