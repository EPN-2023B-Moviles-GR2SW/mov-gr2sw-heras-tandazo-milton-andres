package com.example.a04_deber03_tiktok

import com.google.android.exoplayer2.ExoPlayer

class ExoPlayerItem(
    var exoPlayer: ExoPlayer,
    var position: Int
)