package com.example.a04_deber03_tiktok

data class Video(
    var title: String,
    var url: String
)